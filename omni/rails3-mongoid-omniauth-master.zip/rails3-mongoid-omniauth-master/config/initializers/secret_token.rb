# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rails3MongoidOmniauth::Application.config.secret_token = 'ce0c9e90903f6dea6f661a8ee8edbd5f4bee4428a4c9ba10e255efd63846b23908537c1a07903cb11ac8cd1fadaa639141450ae7880b22b9bffbbfeffb514d80'
