# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Ujsdemo::Application.config.secret_token = 'a84bcb1e5da24923bb86550be0c3235c27e96f984b83da8be418ef6dddf92276d6cb9920e4ff0b488bd4b2309e2cc677a19014b1bd2daad184a02b1bca3a4ecc'
