# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
LazyRegistration::Application.config.secret_key_base = '4c51e0086d7fb219756d67b88d45ef2ddb66a5183d99ca039d532b04f6c42ef2df5b086e80caeb1388fa542452e0e66df8ad1a11dc6dc80e11e88f5c512c51b8'
