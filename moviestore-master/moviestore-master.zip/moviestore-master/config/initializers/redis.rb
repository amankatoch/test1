$redis = Redis.new(:driver => :hiredis)
