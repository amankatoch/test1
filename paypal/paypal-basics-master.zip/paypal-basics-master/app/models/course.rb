class Course < ActiveRecord::Base
end
